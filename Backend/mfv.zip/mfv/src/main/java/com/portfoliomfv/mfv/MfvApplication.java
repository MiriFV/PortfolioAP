package com.portfoliomfv.mfv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MfvApplication {

	public static void main(String[] args) {
		SpringApplication.run(MfvApplication.class, args);
	}

}
